#!/bin/sh
# This is a generated file; do not edit or check into version control.
export "FLUTTER_ROOT=D:\04.-Logiciels\flutter"
export "FLUTTER_APPLICATION_PATH=D:\02.-Cours\SLAM 2\Matière Pro\02.-B2\COURSPT\B2\02-TP\flutter\flutter_application_1\flutter_application_1"
export "FLUTTER_FRAMEWORK_SWIFT_PACKAGE_PATH=D:\02.-Cours\SLAM 2\Matière Pro\02.-B2\COURSPT\B2\02-TP\flutter\flutter_application_1\flutter_application_1\macos\Flutter\ephemeral\Packages\.packages\FlutterFramework"
export "COCOAPODS_PARALLEL_CODE_SIGN=true"
export "FLUTTER_BUILD_DIR=build"
export "FLUTTER_BUILD_NAME=0.1.0"
export "FLUTTER_BUILD_NUMBER=1"
export "DART_OBFUSCATION=false"
export "TRACK_WIDGET_CREATION=true"
export "TREE_SHAKE_ICONS=false"
export "PACKAGE_CONFIG=.dart_tool/package_config.json"
