# Generated code do not commit.
file(TO_CMAKE_PATH "D:\\04.-Logiciels\\flutter" FLUTTER_ROOT)
file(TO_CMAKE_PATH "D:\\02.-Cours\\SLAM 2\\Matière Pro\\02.-B2\\COURSPT\\B2\\02-TP\\flutter\\flutter_application_1\\flutter_application_1" PROJECT_DIR)

set(FLUTTER_VERSION "0.1.0+1" PARENT_SCOPE)
set(FLUTTER_VERSION_MAJOR 0 PARENT_SCOPE)
set(FLUTTER_VERSION_MINOR 1 PARENT_SCOPE)
set(FLUTTER_VERSION_PATCH 0 PARENT_SCOPE)
set(FLUTTER_VERSION_BUILD 1 PARENT_SCOPE)

# Environment variables to pass to tool_backend.sh
list(APPEND FLUTTER_TOOL_ENVIRONMENT
  "FLUTTER_ROOT=D:\\04.-Logiciels\\flutter"
  "PROJECT_DIR=D:\\02.-Cours\\SLAM 2\\Matière Pro\\02.-B2\\COURSPT\\B2\\02-TP\\flutter\\flutter_application_1\\flutter_application_1"
  "FLUTTER_ROOT=D:\\04.-Logiciels\\flutter"
  "FLUTTER_EPHEMERAL_DIR=D:\\02.-Cours\\SLAM 2\\Matière Pro\\02.-B2\\COURSPT\\B2\\02-TP\\flutter\\flutter_application_1\\flutter_application_1\\windows\\flutter\\ephemeral"
  "PROJECT_DIR=D:\\02.-Cours\\SLAM 2\\Matière Pro\\02.-B2\\COURSPT\\B2\\02-TP\\flutter\\flutter_application_1\\flutter_application_1"
  "FLUTTER_TARGET=D:\\02.-Cours\\SLAM 2\\Matière Pro\\02.-B2\\COURSPT\\B2\\02-TP\\flutter\\flutter_application_1\\flutter_application_1\\lib\\main.dart"
  "DART_DEFINES=RkxVVFRFUl9CVUlMRF9OQU1FPTAuMS4w,RkxVVFRFUl9CVUlMRF9OVU1CRVI9MQ==,RkxVVFRFUl9WRVJTSU9OPTMuNDcuNA==,RkxVVFRFUl9DSEFOTkVMPXN0YWJsZQ==,RkxVVFRFUl9HSVRfVVJMPWh0dHBzOi8vZ2l0aHViLmNvbS9mbHV0dGVyL2ZsdXR0ZXIuZ2l0,RkxVVFRFUl9GUkFNRVdPUktfUkVWSVNJT049OTU4NGM2NzEzYg==,RkxVVFRFUl9FTkdJTkVfUkVWSVNJT049MDZhMmUyYTExMA==,RkxVVFRFUl9EQVJUX1ZFUlNJT049My4xMy4z"
  "DART_OBFUSCATION=false"
  "TRACK_WIDGET_CREATION=true"
  "TREE_SHAKE_ICONS=false"
  "PACKAGE_CONFIG=D:\\02.-Cours\\SLAM 2\\Matière Pro\\02.-B2\\COURSPT\\B2\\02-TP\\flutter\\flutter_application_1\\flutter_application_1\\.dart_tool\\package_config.json"
)
